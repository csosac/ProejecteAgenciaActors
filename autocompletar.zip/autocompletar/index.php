<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>

        <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/2.0.0/jquery.min.js"></script>
        <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jqueryui/1.10.2/jquery-ui.min.js"></script>
        <link href="css/jqueryui.css" type="text/css" rel="stylesheet"/>
        <script>
            $(document).ready(function () {
                $("#matricula").autocomplete({
                    source: "buscaralumno.php",
                    minLength: 1
                });

                $("#matricula").focusout(function () {
                    $.ajax({
//                                        async:true,
//                                        type: "POST",
//                                        dataType: "html",
//                                        contentType: "application/x-www-form-urlencoded",
//                                        url:"alumno.php",
//                                        data:{ matricula:$('#matricula')},
//                                        beforeSend:imgEnviar,//crida la funció per esborrar el gif
//                           success: processarPista3, //processa la pista
//                           timeout: 4000,
//                           error:errorAjax // si hi ha error

                        url: 'alumno.php',
                        type: 'POST',
                        dataType: 'json',
                        data: {matricula: $('#matricula').val()}
                    }).done(function (respuesta) {
                        $("#nombre").val(respuesta.nombre);
                        $("#paterno").val(respuesta.paterno);
                        $("#materno").val(respuesta.materno);
                    });
                });
            });
        </script>

    </head>
    <body>

       	<form>
            <label for="matricula">Matricula:</label>
            <input type="text" id="matricula" name="matricula" value=""/>
            <label for="nombre">Nombre:</label>
            <input type="text" id="nombre" name="nombre" value=""/>
            <label for="paterno">Paterno:</label>
            <input type="text" id="paterno" name="paterno" value=""/>
            <label for="materno">Materno:</label>
            <input type="text" id="materno" name="materno" value=""/>
        </form>
    </body>
</html>
